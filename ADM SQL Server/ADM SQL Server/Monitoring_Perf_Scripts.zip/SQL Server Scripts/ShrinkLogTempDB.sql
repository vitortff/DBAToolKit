use tempdb

dbcc shrinkfile ('templog',100)


